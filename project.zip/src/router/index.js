import { createRouter, createWebHashHistory } from "vue-router";

import CloudBudget from './../pages/tasks/budget.vue';
import Bandwidth from './../pages/tasks/bandwidth.vue';
import DataInventory from './../pages/tasks/inventory.vue';
import NsQuota from './../pages/tasks/nsquota.vue';
import Tasks from './../pages/tasks/index.vue';

import NotFound from './../pages/NotFound.vue';

const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/' , redirect: '/tasks/budget'},
    { 
      path: '/tasks',
      name: "My task",
      component: Tasks,
      children: [
        {
          path: 'budget',
          name: 'CloudBudget',
          component: CloudBudget
        },
        {
          path: 'bandwidth',
          name: 'Bandwidth',
          component: Bandwidth
        },
        {
          path: 'inventory',
          name: 'DataInventory',
          component: DataInventory
        },
        {
          path: 'nsquota',
          name: 'NsQuota',
          component: NsQuota
        }
      ]
    },
    {
      path: '/:notFound(.*)',
      name: 'NotFound',
      component: NotFound
    }
  ],
});

export default router;