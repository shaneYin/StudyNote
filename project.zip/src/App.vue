<script>
  import TheHeader from './components/layout/TheHeader.vue'
  
  export default {
    components: { TheHeader }
  }
</script>
<template>
  <the-header></the-header>
  <router-view></router-view>
</template>
