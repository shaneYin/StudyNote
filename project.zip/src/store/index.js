import { createStore } from "vuex";

const store = createStore({
  state() {
    return {
      projectName: 'Offboard Platform China Portal'
    }
  }
});

export default store;