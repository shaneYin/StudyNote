<script>
  import { ElButton } from 'element-plus';
  import OcButton from './../../components/UI-Element-Reset/OcButton.vue';

  export default {
    components: { ElButton, OcButton },
    setup() {
      return {
        btnText: 'Submit'
      }
    }
  }
</script>
<template>
  <div style="height: 1000px;">
    <el-button type="success">{{btnText}}</el-button>
    <oc-button type="success">{{btnText}}</oc-button>
  </div>
  
</template>