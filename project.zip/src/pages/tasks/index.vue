<script>
  import SideBar from "../../components/layout/SideBar.vue";
  import Content from "../../components/layout/Content.vue";

  export default {
    components: { SideBar, Content }
  }
</script>

<template>
  <side-bar></side-bar>
  <content>
    <router-view></router-view>
  </content>
</template>