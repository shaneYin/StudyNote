<template>
  <div class="logo-img-groups">
    <img src="./../../assets/imgs/header/Logo_BMW_GROUP.svg" alt="Bmw Group" class="logo-img">
    <img src="./../../assets/imgs/header/Logo_BMW.svg" alt="Bmw" class="logo-img bmw-logo">
    <img src="./../../assets/imgs/header/Logo_MINI.svg" alt="Bmw MINI" class="logo-img">
    <img src="./../../assets/imgs/header/Logo_Rolls-Royce.svg" alt="Bmw Rolls-Royce" class="logo-img">
  </div>
</template>
<style scoped>
.logo-img-groups {
  display: flex;
  justify-content: space-between;
  align-items: center;

  height: 30px;
}
.logo-img{
  height: 100%;
}
.bmw-logo{
  margin-left: -10px;
}
</style>