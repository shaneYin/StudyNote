<script>
  import { ElButton } from 'element-plus';

  export default {
    components: { ElButton }
  }
</script>
<template>
  <el-button class="local-button" v-bind="$attrs">
    <slot></slot>
  </el-button>
</template>
<style lang="less" scoped>
  .local-button {
    width: 200px;
    height: 40px;
    line-height: 40px;
    color: #fff;
    background-color: @primary-color;
    border-color: @primary-color;
    border-radius: 2px;
    font-size: 16px;
  }
</style>