<script>
import { ElMenu, ElMenuItem, ElSubMenu, ElMenuItemGroup, ElIcon } from 'element-plus'
import router from './../../router/index'

export default {
  components: { ElMenu, ElMenuItem, ElMenuItemGroup, ElSubMenu, ElIcon },
  data() {
    return {
      defaultActive: '1-0'
    }
  },
  computed: {
    routes() {
      console.log(router.options.routes);
      return router.options.routes;
    }
  },
  created() {
    
  }
}
</script>

<template>
  <aside class="sidebar">
    <el-menu
      :default-active="defaultActive"
    >
      <div v-for="(route, index) in routes" :key="index">
        <div v-if="route.name && route.name !== 'NotFound'">
          <el-sub-menu v-if="route.children && route.children.length" :index="index+''">
            <template #title>
              <el-icon><location /></el-icon>
              <span>{{ route.name }}</span>
            </template>
            <el-menu-item v-for="(child, _index) in route.children" 
              :index="index+'-'+_index" 
              :key="index+'-'+_index">

              {{child.name}}
            </el-menu-item>
          </el-sub-menu>
          <el-menu-item v-else :index="index"> {{ route.name }} </el-menu-item>
        </div>
      </div>
    </el-menu>
  </aside>
</template>

<style lang="less" scoped>
  .sidebar{
    position: fixed;
    top: @top-height;
    width: @sidebar-width;
    height: calc(100vh - @top-height);
    background-color: #fff;
    padding: 20px;
    overflow-y: auto;

    font-size: 16px;
    color: @normal-font-color;
  }
</style>