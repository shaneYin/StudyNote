<template>
  <div class="main">
    <slot></slot>
  </div>
</template>

<style lang="less" scoped>
  .main {
    position: relative;
    margin-left: calc(@sidebar-width + @main-gap-width);
    top: calc(@top-height + @main-gap-width);
    bottom: 0;
    left: 0;
    right: 0;
    width: calc(100% - @sidebar-width - @main-gap-width);
    min-height: calc(100vh - @top-height - @main-gap-width);
    background-color: @base-bg-color;
  }
</style>