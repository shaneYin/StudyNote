<script>
import BaseCard from '../UI/BaseCard.vue';
import Logo from '../static/Logo.vue';

export default{
  components: { BaseCard, Logo }
}
</script>
<template>
  <header id="opcp-header">
    <base-card :shadow="true">
      <div class="header-container">
        <div class="logo">
          <logo></logo>
          <div class="project-title">{{ $store.state.projectName }}</div>
        </div>
        <div class="user-handler">
          <div class="help"></div>
          <div class="user"></div>
        </div>
      </div>
    </base-card>
  </header>
</template>
<style lang="less" scoped>
#opcp-header {
  position: fixed;
  background-color: #fff;
  
  width: 100%;
  z-index: 2;
}

.header-container{
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;

  width: 100%;
  height: @top-height;
  padding: 0 25px;
}
.logo{
  display: flex;
  justify-content: space-between;
  align-items: center;

  font-size: 32px;
  color: @normal-font-color;
}

.project-title{
  margin-left: 40px;
}

.user-handler {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.help, .user {
  width: 25px;
  height: 25px;
}
.help {
  cursor: help;
  background: url(./../../assets/imgs/header/help.png);
}
.user {
  margin-left: 10px;
  cursor: pointer;
  background: url(./../../assets/imgs/header/user.png);
}
</style>