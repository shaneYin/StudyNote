<script>
  export default {
    props: ['shadow','border']
  }
</script>
<template>
  <div :class="{'shadow-box': shadow, 'border-box': border}" class="box">
    <slot></slot>
  </div>
</template>
<style scoped>
  .box {
    position: relative;
  }
  .shadow-box{
    box-shadow: 0 2px 4px 0 rgba(102, 102, 102, 0.24);
  }
  .border-box{
    border: 1px solid #dcdfe6;
    border-radius: 2px;
  }
</style>