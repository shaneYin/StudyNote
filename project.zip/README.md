# Offboard Platform China Portal

## Run

Just run **npm install** and then run **npm run dev** to start the dev environment

